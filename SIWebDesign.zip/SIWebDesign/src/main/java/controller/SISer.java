package controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.SI;
/**
 * Servlet implementation class SISer
 */
@WebServlet("/SISer")
public class SISer extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SISer() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	   RequestDispatcher  req = request.getRequestDispatcher("view/siview.jsp");
	   req.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter(); 
		SI s = new SI();
		s.setP(Float.parseFloat(request.getParameter("txtp")));
		s.setR(Float.parseFloat(request.getParameter("txtr")));
		s.setT(Float.parseFloat(request.getParameter("txtt")));
		float si = (s.getP()*s.getR()*s.getT())/100;
		
		RequestDispatcher  req = request.getRequestDispatcher("view/siview.jsp");
		req.include(request, response);
		
		out.write("Result is "+si);
		
	}

}
